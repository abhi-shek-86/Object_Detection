import streamlit as st
from detect import detect_objects, save_results
from PIL import Image
import os

# Create uploads directory if it doesn't exist
if not os.path.exists("uploads"):
    os.makedirs("uploads")

st.title("Object Detection App")

# File uploader
uploaded_file = st.file_uploader("Upload an image...", type=["jpg", "jpeg", "png"])

if uploaded_file is not None:
    # Save uploaded image to 'uploads/' directory
    img_path = os.path.join("uploads", uploaded_file.name)
    with open(img_path, "wb") as f:
        f.write(uploaded_file.getbuffer())

    # Display uploaded image
    st.image(Image.open(img_path), caption='Uploaded Image', use_column_width=True)

    # Perform object detection
    results, detected_objects = detect_objects(img_path)
    detected_image_path = save_results(results, img_path)

    # Display detected image
    st.image(Image.open(detected_image_path), caption='Detected Image', use_column_width=True)

    # Show the detected objects and their confidence scores
    st.write("Detected objects:")
    for obj in detected_objects:
        st.write(f"Object: {obj[0]}, Confidence: {obj[1]:.2f}")
