import torch
import cv2

# Load pre-trained YOLOv5 model
model = torch.hub.load('ultralytics/yolov5', 'yolov5s')  # Load the small YOLO model

def detect_objects(image_path):
    # Read the image
    img = cv2.imread(image_path)
    
    # Perform object detection
    results = model(img)
    
    # Extract detected objects, labels, and confidence scores
    detected_objects = []
    for *box, conf, cls in results.xyxy[0]:  # results.xyxy contains bounding boxes, confidence scores, and class indices
        label = model.names[int(cls)]  # Convert class index to the object label
        detected_objects.append((label, conf.item()))  # Append label and confidence score
    
    return results, detected_objects

def save_results(results, image_path):
    # Save the image with bounding boxes
    result_img = results.render()[0]  # Render detections on the image
    output_path = image_path.replace('.jpg', '_detected.jpg')  # Save with '_detected'
    cv2.imwrite(output_path, result_img)
    print(f"Result saved at {output_path}")
    return output_path
